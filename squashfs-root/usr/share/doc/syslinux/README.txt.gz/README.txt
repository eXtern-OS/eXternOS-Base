			 The Syslinux Project

		   A suite of bootloaders for Linux

	 Copyright 1994-2011 H. Peter Anvin and contributors

This program is provided under the terms of the GNU General Public
License, version 2 or, at your option, any later version.  There is no
warranty, neither expressed nor implied, to the function of this
program.  Please see the included file COPYING for details.

----------------------------------------------------------------------

      Syslinux now has a home page at http://syslinux.zytor.com/

----------------------------------------------------------------------

The Syslinux suite contains the following boot loaders
("derivatives"), for their respective boot media:

	SYSLINUX - MS-DOS/Windows FAT filesystem
	PXELINUX - PXE network booting
	ISOLINUX - ISO9660 CD-ROM
	EXTLINUX - Linux ext2/ext3 filesystem

For historical reasons, some of the sections in this document applies
to the FAT loader (SYSLINUX) only; see pxelinux.txt, isolinux.txt and
extlinux.txt for what differs in these versions.  The all-caps term
"SYSLINUX" generally refers to the FAT loader, whereas "Syslinux"
refers to the project as a whole.

Help with cleaning up the docs would be greatly appreciated.


   ++++ Options ++++

These are the options common to all versions of Syslinux:

	-s	Safe, slow, stupid; uses simpler code that boots better
	-f	Force installing
	-r	Raid mode.  If boot fails, tell the BIOS to boot the next
		device in the boot sequence (usually the next hard disk)
		instead of stopping with an error message.
		This is useful for RAID-1 booting.

These are only in the Windows version:

	-m	Mbr; install a bootable MBR sector to the beginning of the
		drive.
	-a	Active; marks the partition used active (=bootable)


   ++++ CREATING A BOOTABLE LINUX FLOPPY +++

In order to create a bootable Linux floppy using SYSLINUX, prepare a
normal MS-DOS formatted floppy.  Copy one or more Linux kernel files to
it, then execute the DOS command:

        syslinux [-sfrma][-d directory] a: [bootsecfile]

(or whichever drive letter is appropriate; the [] meaning optional.)

Use "syslinux.com" (in the dos subdirectory of the distribution) for
plain DOS (MS-DOS, DR-DOS, PC-DOS, FreeDOS...) or Win9x/ME.

Use "syslinux.exe" (in the win32 subdirectory of the distribution) for
WinNT/2000/XP.

Under Linux, execute the command:

	syslinux [-sfr][-d directory][-o offset] /dev/fd0

(or, again, whichever device is the correct one.)

This will alter the boot sector on the disk and copy a file named
LDLINUX.SYS into its root directory (or a subdirectory, if the -d
option is specified.)

The -s option, if given, will install a "safe, slow and stupid"
version of SYSLINUX.  This version may work on some very buggy BIOSes
on which SYSLINUX would otherwise fail.  If you find a machine on
which the -s option is required to make it boot reliably, please send
as much info about your machine as you can, and include the failure
mode.

The -o option is used with a disk image file and specifies the byte
offset of the filesystem image in the file.

For the DOS and Windows installers, the -m and -a options can be used
on hard drives to write a Master Boot Record (MBR), and to mark the
specific partition active.

If the Shift or Alt keys are held down during boot, or the Caps or Scroll
locks are set, Syslinux will display a LILO-style "boot:" prompt.  The
user can then type a kernel file name followed by any kernel parameters.
The Syslinux loader does not need to know about the kernel file in
advance; all that is required is that it is a file located in the root
directory on the disk.

There are two versions of the Linux installer; one in the "mtools"
directory which requires no special privilege (other than write
permission to the device where you are installing) but requires the
mtools program suite to be available, and one in the "linux" directory
which requires root privilege.


   ++++ CONFIGURATION FILE ++++

All options here apply to PXELINUX, ISOLINUX and EXTLINUX as well as
SYSLINUX unless otherwise noted.  See the respective .txt files.

All the configurable defaults in SYSLINUX can be changed by putting a
file called "syslinux.cfg" in the root directory of the boot disk.

Starting with version 3.35, the configuration file can also be in
either the /boot/syslinux or /syslinux directories (searched in that
order.)  If that is the case, then all filenames are assumed to be
relative to that same directory, unless preceded with a slash or
backslash.

The configuration file is a text file in either UNIX or DOS format,
containing one or more of the following items, each on its own line with
optional leading whitespace.  Case is insensitive for keywords; upper
case is used here to indicate that a word should be typed verbatim.

#comment
	A comment line.

INCLUDE filename
	Inserts the contents of another file at this point in the
	configuration file. Files can currently be nested up to 16
	levels deep, but it is not guaranteed that more than 8 levels
	will be supported in the future.

DEFAULT kernel options...
        Sets the default command line.  If Syslinux boots automatically,
        it will act just as if the entries after DEFAULT had been typed
        in at the "boot:" prompt.

	If no configuration file is present, or no DEFAULT entry is
        present in the config file, an error message is displayed and
	the boot: prompt is shown.

UI module options...
	Selects a specific user interface module (typically menu.c32
	or vesamenu.c32).  The command-line interface treats this as a
	directive that overrides the DEFAULT and PROMPT directives.

APPEND options...
        Add one or more options to the kernel command line.  These are
        added both for automatic and manual boots.  The options are
        added at the very beginning of the kernel command line,
        usually permitting explicitly entered kernel options to override
        them.  This is the equivalent of the LILO "append" option.

SYSAPPEND bitmask
IPAPPEND bitmask

	The SYSAPPEND option was introduced in Syslinux 5.10; it is an
	enhancement of a previous option IPAPPEND which was only
	available on PXELINUX.  bitmask is interpreted as decimal format
	unless prefixed with "0x" for hexadecimal or "0" (zero) for
	octal.

	1: indicates that an option of the following format
	should be generated and added to the kernel command line:

		ip=<client-ip>:<boot-server-ip>:<gw-ip>:<netmask>

	... based on the input from the DHCP/BOOTP or PXE boot server.

	NOTE: The use of this option is no substitute for running a
	DHCP client in the booted system.  Without regular renewals,
	the lease acquired by the PXE BIOS will expire, making the
	IP address available for reuse by the DHCP server.

	This option is empty for non-PXELINUX.

	2: indicates that an option of the following format
	should be generated and added to the kernel command line:

		BOOTIF=<hardware-address-of-boot-interface>

	... in dash-separated hexadecimal with leading hardware type
	(same as for the configuration file; see pxelinux.txt.)

	This allows an initrd program to determine from which
	interface the system booted.

	This option is empty for non-PXELINUX.

	4: indicates that an option of the following format
	should be generated and added to the kernel command line:

		SYSUUID=<system uuid>

	... in lower case hexadecimal in the format normally used for
	UUIDs (same as for the configuration file; see pxelinux.txt.)
	This may not be available if no valid UUID is found on the
	system.

	8: indicate the CPU family and certain particularly
	significant CPU feature bits:

		CPU=<family><features>

	The <family> is a single digit from 3 (i386) to 6 (i686 or
	higher.)  The following CPU feature are currently reported;
	additional flags may be added in the future:

		P	Physical Address Extension (PAE)
		V	Intel Virtualization Technology (VT/VMX)
		T	Intel Trusted Exection Technology (TXT/SMX)
		X	Execution Disable (XD/NX)
		L	Long Mode (x86-64)
		S	AMD SMX virtualization
	
	This was added in 5.10.

	The following strings are derived from DMI/SMBIOS information
	if available; these are all new in version 5.10:
	
	Bit	String		Significance
	-------------------------------------------------------------
	0x00010	SYSVENDOR=	System vendor name
	0x00020	SYSPRODUCT=	System product name
	0x00040	SYSVERSION=	System version
	0x00080	SYSSERIAL=	System serial number
	0x00100	SYSSKU=		System SKU
	0x00200	SYSFAMILY=	System family
	0x00400	MBVENDOR=	Motherboard vendor name
	0x00800	MBVERSION=	Motherboard version
	0x01000	MBSERIAL=	Motherboard serial number
	0x02000	MBASSET=	Motherboard asset tag
	0x04000 BIOSVENDOR=	BIOS vendor name
	0x08000	BIOSVERSION=	BIOS version
	0x10000	SYSFF=		System form factor

	If these strings contain whitespace they are replaced with
	underscores (_).

	The system form factor value is a number defined in the SMBIOS
	specification, available at http://www.dmtf.org/.  As of
	version 2.7.1 of the specification, the following values are
	defined:

	  1	Other
	  2	Unknown
	  3	Desktop
	  4	Low profile desktop
	  5	Pizza box
	  6	Mini tower
	  7	Tower
	  8	Portble
	  9	Laptop
	 10	Notebook
	 11	Handheld
	 12	Docking station
	 13	All-in-one
	 14	Subnotebook
	 15	Space-saving
	 16	Lunch box
	 17	Main server chassis
	 18	Expansion chassis
	 19	Subchassis
	 20	Bus expansion chassis
	 21	Peripheral chassis
	 22	RAID chassis
	 23	Rack mount chasss
	 24	Sealed-case PC
	 25	Multi-system chassis
	 26	Compact PCI
	 27	Advanced TCI
	 28	Blade
	 29	Blade enclosure

SENDCOOKIES bitmask			[PXELINUX only]

	When downloading files over http, the SYSAPPEND strings are
	prepended with _Syslinux_ and sent to the server as cookies.
	The cookies are URL-encoded; whitespace is *not* replaced with
	underscores.

	This command limits the cookies send; 0 means no cookies.  The
	default is -1, meaning send all cookies.

	This option is "sticky" and is not automatically reset when
	loading a new configuration file with the CONFIG command.

LABEL label
    KERNEL image
    APPEND options...
    SYSAPPEND flag_val			[5.10+]
    IPAPPEND flag_val			[5.10+ or PXELINUX only]
	Indicates that if "label" is entered as the kernel to boot,
        Syslinux should instead boot "image", and the specified APPEND
	and SYSAPPEND options should be used instead of the ones
        specified in the global section of the file (before the first
        LABEL command.)  The default for "image" is the same as
        "label", and if no APPEND is given the default is to use the
        global entry (if any).

	Starting with version 3.62, the number of LABEL statements is
	virtually unlimited.

        Note that LILO uses the syntax:
        image = mykernel
          label = mylabel
          append = "myoptions"

        ... whereas Syslinux uses the syntax:
        label mylabel
          kernel mykernel
          append myoptions

	Note: The "kernel" doesn't have to be a Linux kernel; it can
	      be a boot sector (see below.)

	Since version 3.32 label names are no longer mangled into DOS
	format (for SYSLINUX.)

    The following commands are available after a LABEL statement:

    LINUX image			- Linux kernel image (default)
    BOOT image			- Bootstrap program (.bs, .bin)
    BSS image			- BSS image (.bss)
    PXE image			- PXE Network Bootstrap Program (.0)
    FDIMAGE image		- Floppy disk image (.img)
    COM32 image			- COM32 program (.c32)
    CONFIG image		- New configuration file
	Using one of these keywords instead of KERNEL forces the
	filetype, regardless of the filename.

	CONFIG means restart the boot loader using a different
	configuration file.  The configuration file is read, the
	working directory is changed (if specified via an APPEND), then
	the configuration file is parsed.

    APPEND -
        Append nothing.  APPEND with a single hyphen as argument in a
        LABEL section can be used to override a global APPEND.

    LOCALBOOT type
	Attempt a different local boot method.  The special value -1
	causes the boot loader to report failure to the BIOS, which, on
	recent BIOSes, should mean that the next boot device in the
	boot sequence should be activated.  Values other than those
	documented may produce undesired results.

	On PXELINUX, "type" 0 means perform a normal boot.  "type" 4
	will perform a local boot with the Universal Network Driver
	Interface (UNDI) driver still resident in memory.  Finally,
	"type" 5 will perform a local boot with the entire PXE
	stack, including the UNDI driver, still resident in memory.
	All other values are undefined.  If you don't know what the
	UNDI or PXE stacks are, don't worry -- you don't want them,
	just specify 0.

	On ISOLINUX, the "type" specifies the local drive number to
	boot from; 0x00 is the primary floppy drive and 0x80 is the
	primary hard drive.

    INITRD initrd_file
	Starting with version 3.71, an initrd can be specified in a
	separate statement (INITRD) instead of as part of the APPEND
	statement; this functionally appends "initrd=initrd_file" to
	the kernel command line.

	It supports multiple filenames separated by commas.
	This is mostly useful for initramfs, which can be composed of
	multiple separate cpio or cpio.gz archives.
	Note: all files except the last one are zero-padded to a
	4K page boundary.  This should not affect initramfs.

IMPLICIT flag_val
        If flag_val is 0, do not load a kernel image unless it has been
        explicitly named in a LABEL statement.  The default is 1.

ALLOWOPTIONS flag_val
	If flag_val is 0, the user is not allowed to specify any
	arguments on the kernel command line.  The only options
	recognized are those specified in an APPEND statement.  The
	default is 1.

TIMEOUT timeout
        Indicates how long to wait at the boot: prompt until booting
        automatically, in units of 1/10 s.  The timeout is cancelled as
        soon as the user types anything on the keyboard, the assumption
        being that the user will complete the command line already
        begun.  A timeout of zero will disable the timeout completely,
        this is also the default.

TOTALTIMEOUT timeout
        Indicates how long to wait until booting automatically, in
	units of 1/10 s.  This timeout is *not* cancelled by user
	input, and can thus be used to deal with serial port glitches
	or "the user walked away" type situations.  A timeout of zero
	will disable the timeout completely, this is also the default.

	Both TIMEOUT and TOTALTIMEOUT can be used together, for
	example:

		# Wait 5 seconds unless the user types something, but
		# always boot after 15 minutes.
		TIMEOUT 50
		TOTALTIMEOUT 9000

ONTIMEOUT kernel options...
	Sets the command line invoked on a timeout.  Normally this is
	the same thing as invoked by "DEFAULT".  If this is specified,
	then "DEFAULT" is used only if the user presses <Enter> to
	boot.

ONERROR kernel options...
	If a kernel image is not found (either due to it not existing,
	or because IMPLICIT is set), run the specified command.  The
	faulty command line is appended to the specified options, so
	if the ONERROR directive reads as:

		ONERROR xyzzy plugh

	... and the command line as entered by the user is:

		foo bar baz

	... Syslinux will execute the following as if entered by the
	user:

		xyzzy plugh foo bar baz

SERIAL port [baudrate [flowcontrol]]
	Enables a serial port to act as the console.  "port" is a
	number (0 = /dev/ttyS0 = COM1, etc.) or an I/O port address
	(e.g. 0x3F8); if "baudrate" is omitted, the baud rate defaults
	to 9600 bps.  The serial parameters are hardcoded to be 8
	bits, no parity, 1 stop bit.

	"flowcontrol" is a combination of the following bits:
	0x001 - Assert DTR
	0x002 - Assert RTS
	0x008 - Enable interrupts
	0x010 - Wait for CTS assertion
	0x020 - Wait for DSR assertion
	0x040 - Wait for RI assertion
	0x080 - Wait for DCD assertion
	0x100 - Ignore input unless CTS asserted
	0x200 - Ignore input unless DSR asserted
	0x400 - Ignore input unless RI asserted
	0x800 - Ignore input unless DCD asserted

	All other bits are reserved.

	Typical values are:

	    0 - No flow control (default)
	0x303 - Null modem cable detect
	0x013 - RTS/CTS flow control
	0x813 - RTS/CTS flow control, modem input
	0x023 - DTR/DSR flow control
	0x083 - DTR/DCD flow control

	For the SERIAL directive to be guaranteed to work properly, it
	should be the first directive in the configuration file.

	NOTE: "port" values from 0 to 3 means the first four serial
	ports detected by the BIOS.  They may or may not correspond to
	the legacy port values 0x3F8, 0x2F8, 0x3E8, 0x2E8.

	Enabling interrupts (setting the 0x008 bit) may give better
	responsiveness without setting the NOHALT option, but could
	potentially cause problems with buggy BIOSes.

	This option is "sticky" and is not automatically reset when
	loading a new configuration file with the CONFIG command.

NOHALT flag_val
	If flag_val is 1, don't halt the processor while idle.
	Halting the processor while idle significantly reduces the
	power consumption, but can cause poor responsiveness to the
	serial console, especially when using scripts to drive the
	serial console, as opposed to human interaction.

CONSOLE flag_val
	If flag_val is 0, disable output to the normal video console.
	If flag_val is 1, enable output to the video console (this is
	the default.)

	Some BIOSes try to forward this to the serial console and
	sometimes make a total mess thereof, so this option lets you
	disable the video console on these systems.

FONT filename
	Load a font in .psf format before displaying any output
	(except the copyright line, which is output as ldlinux.sys
	itself is loaded.)  Syslinux only loads the font onto the
	video card; if the .psf file contains a Unicode table it is
	ignored.  This only works on EGA and VGA cards; hopefully it
	should do nothing on others.

KBDMAP keymap
	Install a simple keyboard map.  The keyboard remapper used is
	*very* simplistic (it simply remaps the keycodes received from
	the BIOS, which means that only the key combinations relevant
	in the default layout -- usually U.S. English -- can be
	mapped) but should at least help people with AZERTY keyboard
	layout and the locations of = and , (two special characters
	used heavily on the Linux kernel command line.)

	The included program keytab-lilo.pl from the LILO distribution
	can be used to create such keymaps.  The file keytab-lilo.txt
	contains the documentation for this program.

DISPLAY filename
	Displays the indicated file on the screen at boot time (before
        the boot: prompt, if displayed).  Please see the section below
        on DISPLAY files.

        NOTE: If the file is missing, this option is simply ignored.

SAY message
	Prints the message on the screen.

PROMPT flag_val
        If flag_val is 0, display the boot: prompt only if the Shift or Alt
        key is pressed, or Caps Lock or Scroll lock is set (this is the
        default).  If flag_val is 1, always display the boot: prompt.

NOESCAPE flag_val
	If flag_val is set to 1, ignore the Shift/Alt/Caps Lock/Scroll
	Lock escapes.  Use this (together with PROMPT 0) to force the
	default boot alternative.

NOCOMPLETE flag_val
	If flag_val is set to 1, the Tab key does not display labels
	at the boot: prompt.

F1 filename
F2 filename
   ...etc...
F9 filename
F10 filename
F11 filename
F12 filename
        Displays the indicated file on the screen when a function key is
        pressed at the boot: prompt.  This can be used to implement
        pre-boot online help (presumably for the kernel command line
        options.)  Please see the section below on DISPLAY files.

	When using the serial console, press <Ctrl-F><digit> to get to
	the help screens, e.g. <Ctrl-F><2> to get to the F2 screen.
	For F10-F12, hit <Ctrl-F><A>, <Ctrl-F>B, <Ctrl-F>C.  For
	compatibility with earlier versions, F10 can also be entered as
	<Ctrl-F>0.

PATH path
	Specify a colon-separated (':') list of directories to search
	when attempting to load modules. This directive is useful for
	specifying the directories containing the lib*.c32 library
	files as other modules may be dependent on these files, but
	may not reside in the same directory. The list of directories
	is searched in order. Please see the section below on PATH
	RULES.

Blank lines are ignored.

Note that the configuration file is not completely decoded.  Syntax
different from the one described above may still work correctly in this
version of Syslinux, but may break in a future one.


   ++++ DISPLAY FILE FORMAT ++++

DISPLAY and function-key help files are text files in either DOS or UNIX
format (with or without <CR>).  In addition, the following special codes
are interpreted:

<FF>                                    <FF> = <Ctrl-L> = ASCII 12
        Clear the screen, home the cursor.  Note that the screen is
        filled with the current display color.

<SI><bg><fg>                            <SI> = <Ctrl-O> = ASCII 15
        Set the display colors to the specified background and
        foreground colors, where <bg> and <fg> are hex digits,
        corresponding to the standard PC display attributes:

        0 = black               8 = dark grey
        1 = dark blue           9 = bright blue
        2 = dark green          a = bright green
        3 = dark cyan           b = bright cyan
        4 = dark red            c = bright red
        5 = dark purple         d = bright purple
        6 = brown               e = yellow
        7 = light grey          f = white

        Picking a bright color (8-f) for the background results in the
        corresponding dark color (0-7), with the foreground flashing.

	Colors are not visible over the serial console.

<CAN>filename<newline>			<CAN> = <Ctrl-X> = ASCII 24
	If a VGA display is present, enter graphics mode and display
	the graphic included in the specified file.  The file format
	is an ad hoc format called LSS16; the included Perl program
	"ppmtolss16" can be used to produce these images.  This Perl
	program also includes the file format specification.

	The image is displayed in 640x480 16-color mode.  Once in
	graphics mode, the display attributes (set by <SI> code
	sequences) work slightly differently: the background color is
	ignored, and the foreground colors are the 16 colors specified
	in the image file.  For that reason, ppmtolss16 allows you to
	specify that certain colors should be assigned to specific
	color indicies.

	Color indicies 0 and 7, in particular, should be chosen with
	care: 0 is the background color, and 7 is the color used for
	the text printed by Syslinux itself.

<EM>					<EM> = <Ctrl-Y> = ASCII 25
	If we are currently in graphics mode, return to text mode.

<DLE>..<ETB>				<Ctrl-P>..<Ctrl-W> = ASCII 16-23
	These codes can be used to select which modes to print a
	certain part of the message file in.  Each of these control
	characters select a specific set of modes (text screen,
	graphics screen, serial port) for which the output is actually
	displayed:

	Character			Text	Graph	Serial
	------------------------------------------------------
	<DLE> = <Ctrl-P> = ASCII 16	No	No	No
	<DC1> = <Ctrl-Q> = ASCII 17	Yes	No	No
	<DC2> = <Ctrl-R> = ASCII 18	No	Yes	No
	<DC3> = <Ctrl-S> = ASCII 19	Yes	Yes	No
	<DC4> = <Ctrl-T> = ASCII 20	No	No	Yes
	<NAK> = <Ctrl-U> = ASCII 21	Yes	No	Yes
	<SYN> = <Ctrl-V> = ASCII 22	No	Yes	Yes
	<ETB> = <Ctrl-W> = ASCII 23	Yes	Yes	Yes

	For example:

	<DC1>Text mode<DC2>Graphics mode<DC4>Serial port<ETB>

	... will actually print out which mode the console is in!

<SUB>                                   <SUB> = <Ctrl-Z> = ASCII 26
        End of file (DOS convention).

<BEL>					<BEL> = <Ctrl-G> = ASCII 7
	Beep the speaker.


   ++++ COMMAND LINE KEYSTROKES ++++

The command line prompt supports the following keystrokes:

<Enter>		boot specified command line
<BackSpace>	erase one character
<Ctrl-U>	erase the whole line
<Ctrl-V>	display the current Syslinux version
<Ctrl-W>	erase one word
<Ctrl-X>	force text mode
<Tab>		list matching labels
<F1>..<F12>	help screens (if configured)
<Ctrl-F><digit>	equivalent to F1..F10
<Ctrl-C>	interrupt boot in progress
<Esc>		interrupt boot in progress
<Ctrl-N>	display network information (PXELINUX only)


   ++++ OTHER OPERATING SYSTEMS ++++

This version of Syslinux supports chain loading of other operating
systems (such as MS-DOS and its derivatives, including Windows 95/98).

Chain loading requires the boot sector of the foreign operating system
to be stored in a file in the root directory of the filesystem.
Because neither Linux kernels, nor boot sector images have reliable
magic numbers, Syslinux will look at the file extension.
The following extensions are recognized (case insensitive):

  none or other	Linux kernel image
  .0		PXE bootstrap program (NBP) [PXELINUX only]
  .bin		"CD boot sector" [ISOLINUX only]
  .bs		Boot sector [SYSLINUX only]
  .bss		Boot sector, DOS superblock will be patched in [SYSLINUX only]
  .c32		COM32 image (32-bit ELF)
  .img		Disk image [ISOLINUX only]

For filenames given on the command line, Syslinux will search for the
file by adding extensions in the order listed above if the plain
filename is not found.  Filenames in KERNEL statements must be fully
qualified.

If this is specified with one of the keywords LINUX, BOOT, BSS,
FDIMAGE, COM32, or CONFIG instead of KERNEL, the filetype is
considered to be the one specified regardless of the filename.


      ++++ BOOTING DOS (OR OTHER SIMILAR OPERATING SYSTEMS) ++++

This section applies to SYSLINUX only, not to PXELINUX or ISOLINUX.
See isolinux.txt for an equivalent procedure for ISOLINUX.

This is the recommended procedure for creating a SYSLINUX disk that
can boot either DOS or Linux.  This example assumes the drive is A: in
DOS and /dev/fd0 in Linux; for other drives, substitute the
appropriate drive designator.

   ---- Linux procedure ----

1. Make a DOS bootable disk.  This can be done either by specifying
   the /s option when formatting the disk in DOS, or by running the
   DOS command SYS (this can be done under DOSEMU if DOSEMU has
   direct device access to the relevant drive):

	format a: /s
   or
	sys a:

2. Boot Linux.  Copy the DOS boot sector from the disk into a file:

	dd if=/dev/fd0 of=dos.bss bs=512 count=1

3. Run SYSLINUX on the disk:

	syslinux /dev/fd0

4. Mount the disk and copy the DOS boot sector file to it.  The file
   *must* have extension .bss:

	mount -t msdos /dev/fd0 /mnt
	cp dos.bss /mnt

5. Copy the Linux kernel image(s), initrd(s), etc to the disk, and
   create/edit syslinux.cfg and help files if desired:

	cp vmlinux /mnt
	cp initrd.gz /mnt

6. Unmount the disk (if applicable.)

	umount /mnt

   ---- DOS/Windows procedure ----

To make this installation in DOS only, you need the utility copybs.com
(included with Syslinux) as well as the syslinux.com installer.  If
you are on an WinNT-based system (WinNT, Win2k, WinXP or later), use
syslinux.exe instead.

1. Make a DOS bootable disk.  This can be done either by specifying
   the /s option when formatting the disk in DOS, or by running the
   DOS command SYS:

	format a: /s
   or
	sys a:

2. Copy the DOS boot sector from the disk into a file.  The file
   *must* have extension .bss:

	copybs a: a:dos.bss

3. Run SYSLINUX on the disk:

	syslinux a:

4. Copy the Linux kernel image(s), initrd(s), etc to the disk, and
   create/edit syslinux.cfg and help files if desired:

	copy vmlinux a:
	copy initrd.gz a:


   ++++ NOVICE PROTECTION ++++

Syslinux will attempt to detect booting on a machine with too little
memory, which means the Linux boot sequence cannot complete.  If so, a
message is displayed and the boot sequence aborted.  Holding down the
Ctrl key while booting disables this feature.

Any file that SYSLINUX uses can be marked hidden, system or readonly
if so is convenient; SYSLINUX ignores all file attributes.  The
SYSLINUX installed automatically sets the readonly/hidden/system
attributes on LDLINUX.SYS.


   ++++ NOTES ON BOOTABLE CD-ROMS ++++

SYSLINUX can be used to create bootdisk images for El
Torito-compatible bootable CD-ROMs.  However, it appears that many
BIOSes are very buggy when it comes to booting CD-ROMs.  Some users
have reported that the following steps are helpful in making a CD-ROM
that is bootable on the largest possible number of machines:

	a) Use the -s (safe, slow and stupid) option to SYSLINUX;
	b) Put the boot image as close to the beginning of the
	   ISO 9660 filesystem as possible.

A CD-ROM is so much faster than a floppy that the -s option shouldn't
matter from a speed perspective.

Of course, you probably want to use ISOLINUX instead.  See isolinux.txt.


   ++++ BOOTING FROM A FAT FILESYSTEM PARTITION ON A HARD DISK ++++

SYSLINUX can boot from a FAT filesystem partition on a hard disk
(including FAT32).  The installation procedure is identical to the
procedure for installing it on a floppy, and should work under either
DOS or Linux.  To boot from a partition, SYSLINUX needs to be launched
from a Master Boot Record or another boot loader, just like DOS itself
would.

Under DOS, you can install a standard simple MBR on the primary hard
disk by running the command:

	FDISK /MBR

Then use the FDISK command to mark the appropriate partition active.

A simple MBR, roughly on par with the one installed by DOS (but
unencumbered), is included in the SYSLINUX distribution.  To install
it under Linux, simply type:

	cat mbr.bin > /dev/XXX

... where /dev/XXX is the device you wish to install it on.

Under DOS or Win32, you can install the SYSLINUX MBR with the -m
option to the SYSLINUX installer, and use the -a option to mark the
current partition active:

	syslinux -ma c:

Note that this will also install SYSLINUX on the specified partition.


   ++++ HARDWARE INFORMATION +++

I have started to maintain a web page of hardware with known
problems.  There are, unfortunately, lots of broken hardware out
there; especially early PXE stacks (for PXELINUX) have lots of
problems.

A list of problems, and workarounds (if known), is maintained at:

	http://syslinux.zytor.com/hardware.php


   ++++ BOOT LOADER IDS USED ++++

The Linux boot protocol supports a "boot loader ID", a single byte
where the upper nybble specifies a boot loader family (3 = Syslinux)
and the lower nybble is version or, in the case of Syslinux, media:

	0x31 (49) = SYSLINUX
	0x32 (50) = PXELINUX
	0x33 (51) = ISOLINUX
	0x34 (52) = EXTLINUX

In recent versions of Linux, this ID is available as
/proc/sys/kernel/bootloader_type.


   ++++ PATH RULES ++++

The current working directory is *always* searched first, before PATH,
when attempting to open a filename. The current working directory is
not affected when specifying a file with an absolute path. For
example, given the following file system layout,

	 /boot/
		/bin/
			ls.c32
			libls.c32
		/foo/
			libls.c32

assuming that the current working directory is /boot/foo, and assuming
that libls.c32 is a dependency of ls.c32, executing /boot/bin/ls.c32
will cause /boot/foo/libls.c32 to be loaded, not /boot/bin/libls.c32,
even if /boot/bin is specified in the PATH directive of a config file.

The reason that things work this way is that typically a user will
install all library files in the Syslinux installation directory, as
specified with the --directory installer option. This method allows
the user to omit the PATH directive from their config file and still
have things work correctly.


   ++++ BUG REPORTS ++++

I would appreciate hearing of any problems you have with Syslinux.  I
would also like to hear from you if you have successfully used Syslinux,
*especially* if you are using it for a distribution.

If you are reporting problems, please include all possible information
about your system and your BIOS; the vast majority of all problems
reported turn out to be BIOS or hardware bugs, and I need as much
information as possible in order to diagnose the problems.

There is a mailing list for discussion among Syslinux users and for
announcements of new and test versions.  To join, or to browse the
archive, go to:

   http://www.zytor.com/mailman/listinfo/syslinux

Please DO NOT send HTML messages or attachments to the mailing list
(including multipart/alternative or similar.)  All such messages will
be bounced.
