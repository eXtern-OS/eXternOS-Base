<?
$submit_button_text       = "Wygeneruj";
$message_algorithm        = "Algorytm";
$message_amount_length    = "Ilo�� i d�ugo��";
$message_symbol_sets      = "Zestawy znak�w";
$message_user_random_seed = "Ziarno u�ytkownika";
$message_save_settings    = "Zapisz ustawienia w \"cookie\"";
$message_remove_saved     = "Usu� zapisane ustawienia";
$message_command_line     = "Linia polecenia";
$message_generated_pass   = "Wygenerowane has�a";
$message_yes              = "Tak";
$message_no               = "Nie";
$submessage_pronounceable = "Wymawialne:";
$submessage_random        = "Losowe:";
$submessage_num_of_pass   = "Ilo�� hase� do wygenerowania:";
$submessage_min_pass_len  = "Minimalna d�ugo�� has�a:";
$submessage_max_pass_len  = "Maksymalna d�ugo�� has�a:";
$submessage_small_lerrers = "Ma�e litery:";
$submessage_cap_letters   = "Du�e litery:";
$submessage_numbers       = "Liczby";
$submessage_spec_symbols  = "Znaki specjalne:";
$submessage_seed          = "Ziarno:";
$submessage_up_to         = "do 255";
header( "Content-type: text/html; charset=iso-8859-2" );
header ("Pragma: no-cache");
?>
